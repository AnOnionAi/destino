from .mcts import *

__doc__ = mcts.__doc__
