from zarena.gym_checkers.envs.checkers import CheckersEnv
